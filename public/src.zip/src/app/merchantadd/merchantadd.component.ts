import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchantadd',
  templateUrl: './merchantadd.component.html',
  styleUrls: ['./merchantadd.component.css']
})
export class MerchantaddComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
